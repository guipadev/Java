package com.coffeepoweredcrew.facade.email;

public interface Stationary {

	String getHeader();
	
	String getFooter();
}
