package com.coffeepoweredcrew.facade.email;

import com.coffeepoweredcrew.facade.Order;
import com.coffeepoweredcrew.facade.email.Template.TemplateType;

//Facade provides simple methods for client to use
public class EmailFacade {
	
}
